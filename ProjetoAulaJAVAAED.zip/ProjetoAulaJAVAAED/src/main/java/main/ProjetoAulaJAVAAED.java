package main;

import com.mycompany.projetoaulajavaaed.Banco;
import com.mycompany.projetoaulajavaaed.ContaCorrente;

/**
 *
 * @author Samir e Vinicius
 */

public class ProjetoAulaJAVAAED {

    public static void main(String[] args) {
       
        ContaCorrente cc1 = new ContaCorrente();
        ContaCorrente cc2 = new ContaCorrente();
        ContaCorrente cc3 = new ContaCorrente();
        
        Banco banco = new Banco(123, "Bradesco");
        
        banco.abrirConta(cc1);
        banco.abrirConta(cc2);
        banco.abrirConta(cc3);
    }
}
