package com.mycompany.projetoaulajavaaed;

public class ContaCorrente {
    
    private int nc;
    private String cpf;
    private float saldo;
    
    public int getNc() {
        return this.nc;
    }
    
    public String getCpf() {
        return this.cpf;
    }
    
    public float getSaldo() {
        return this.saldo;
    }
    
    public void setSaldo(Long saldo) {
        this.saldo = saldo;
    }
    
    public float depositar(float valor) {
        return saldo += valor;
    }
    
    public float sacar(float valor) {
        return saldo -= (valor * 0.5);
    }
    
    public void exibe() {
        System.out.println("Numero da conta: " + nc);
        System.out.println("cpf: " + cpf);
        System.out.println("saldo" + saldo);
    }
    
    public void erro() {
        System.out.println("Não existe esse cpf");
    }
    
}
