package com.mycompany.projetoaulajavaaed;
import com.mycompany.projetoaulajavaaed.ContaCorrente.java;
import java.util.ArrayList;

public class Banco {
    
    private int ci;
    private String nome; 
    private ArrayList<ContaCorrente> correntistas;
    
    public Banco(int ci, String nome) {
        this.ci = ci;
        this.nome = nome;
        correntistas = new ArrayList<>();
    }
    
      public int getCi() {
        return this.ci;
    }
    
    public String getNome() {
        return this.nome;
    }
  
      public void setNome(String nome) {
        this.nome = nome;
    }
    
    public ContaCorrente getCorrentistas(String cpf) {
        
        for (int i = 0; i < correntistas.size(); i++) {
           ContaCorrente cc = correntistas.get(i);
           if (cc.getCpf().equals(cpf)) {
               return cc;
           }  
        }
        return null;
    }
    
    public void abrirConta(ContaCorrente cc) {
        correntistas.add(cc);
    }
    
    public void encerrarConta(int index) {
        correntistas.remove(index);
    }
        
    public void exibeCorrentistas(String cpf) {
        ContaCorrente cc = new ContaCorrente();
        System.out.println("Codigo identificador: " + ci);
        System.out.println("Nome: " + nome);
        for (ContaCorrente c : correntistas) {
            cc.exibe();
        }
    }
}
